package CIE;

public class Internals extends Student
{
   public int marks[]=new int[5];
}

