package CIE;
public class Student
{
   public String usn,name;
   public int sem;
}

class Internals extends Student
{
   int marks[]=new int[5];
}



   
   
