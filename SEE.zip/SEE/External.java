package SEE;
import CIE.Student;
public class External extends Student
{
  public int sem_marks[]=new int[5];
}
